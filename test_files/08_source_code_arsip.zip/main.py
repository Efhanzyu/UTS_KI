print('Sistem Pengaman Berkas Terdistribusi')
